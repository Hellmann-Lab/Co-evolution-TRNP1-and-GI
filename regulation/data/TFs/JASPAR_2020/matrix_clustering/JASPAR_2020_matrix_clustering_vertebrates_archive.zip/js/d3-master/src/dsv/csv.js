import "dsv";

d3.csv = d3.dsv(",", "text/csv");
